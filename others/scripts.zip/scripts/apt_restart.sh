~/apache-tomcat-8.5/bin/shutdown.sh
~/apache-tomcat-8.5/bin/startup.sh
