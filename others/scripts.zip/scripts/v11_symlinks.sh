ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-localcdn/target/webapp-current ~/tomcat/apache-tomcat-11.0.24/webapps/cdn

ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-admin/target/webapp-current ~/tomcat/apache-tomcat-11.0.24/webapps/admin

ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-retailers/target/webapp-current ~/tomcat/apache-tomcat-11.0.24/webapps/retailers

ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-customer/target/webapp-current ~/tomcat/apache-tomcat-11.0.24/webapps/customer

ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-callback/target/webapp-current ~/tomcat/apache-tomcat-11.0.24/webapps/callback

ln -s ~/working/sunnypoint-v3/src/sunnypoint-server/target/webapp-current ~/tomcat/apache-tomcat-11.0.24/webapps/api
ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-takeout/target/webapp-current ~/tomcat/apache-tomcat-11.0.24/webapps/takeout

ln -s ~/working/sunnypoint-v3/src/sunnypoint-liquibase-runner/target/webapp-current ~/tomcat/apache-tomcat-11.0.24-batch/webapps/liquibase
ln -s ~/working/sunnypoint-v3/src/sunnypoint-batch/target/webapp-current ~/tomcat/apache-tomcat-11.0.24-batch/webapps/batch

ln -s ~/working/sunnypoint-v3/src/sunnypoint-coupon-batch/target/webapp-current ~/tomcat/apache-tomcat-11.0.24-batch/webapps/coupon-batch

ln -s ~/working/sunnypoint-v3/src/sunnypoint-message-sender/target/webapp-current ~/tomcat/apache-tomcat-11.0.24-batch/webapps/sender



