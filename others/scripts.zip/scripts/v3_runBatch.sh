~/apache-tomcat-9.0.89-batch/bin/catalina.sh run
