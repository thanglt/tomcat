~/tomcat-experience/bin/shutdown.sh
~/tomcat-experience/bin/startup.sh