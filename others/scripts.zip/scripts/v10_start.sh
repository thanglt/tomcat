aws s3 mb s3://sunnypoint-media-dev --endpoint-url=http://localhost.localstack.cloud:4566 --no-sign-request
aws s3 mb s3://sunnypoint-export-dev --endpoint-url=http://localhost.localstack.cloud:4566 --no-sign-request

cp ~/etc/env/local-overrides-me.properties ~/etc/local-overrides.properties
~/tomcat/apache-tomcat-10.1.57/bin/startup.sh
~/tomcat/apache-tomcat-10.1.57-batch/bin/startup.sh
