ngrok http --url=nebula-husked-unmatched.ngrok-free.dev 8080



https://sunnypoint-vn.sunnypoint.jp/customer/hitap/checkin?accountId=08caec7a-c4b6-455d-a0d6-e58b5df325c9&retailerId=9f28aa52-90d4-49b5-a36d-916e788c2afa&couponId=41b5994b-d37a-44cb-a1a7-71dc12221fd0

http://localhost:83/customer/hitap/checkin?accountId=08caec7a-c4b6-455d-a0d6-e58b5df325c9&retailerId=9f28aa52-90d4-49b5-a36d-916e788c2afa&couponId=41b5994b-d37a-44cb-a1a7-71dc12221fd0

