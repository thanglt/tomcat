~/apache-tomcat-9.0.89/bin/shutdown.sh
~/apache-tomcat-9.0.89/bin/startup.sh
~/apache-tomcat-9.0.89-batch/bin/shutdown.sh
~/apache-tomcat-9.0.89-batch/bin/startup.sh



