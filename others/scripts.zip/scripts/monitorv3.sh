#!/bin/zsh
# Monitor the local v3 Tomcats (web + batch) and their logs.
#   monitorv3.sh          start the loop in the foreground (Ctrl-C or "monitorv3.sh stop" to end it)
#   monitorv3.sh stop     stop a running monitor
#   monitorv3.sh status   is a monitor running?
# Alerts: printed with an "ALERT" prefix, appended to ~/logs/monitorv3/alerts.log and shown as a macOS notification.

INTERVAL=${MONITORV3_INTERVAL:-30}
STATE_DIR=~/logs/monitorv3
PID_FILE=$STATE_DIR/monitorv3.pid
ALERT_LOG=$STATE_DIR/alerts.log
TOMCATS=(apache-tomcat-10.1.57:83 apache-tomcat-10.1.57-batch:8089)
APP_LOG_DIR=~/logs/sunnypoint
IGNORE_FILE=~/scripts/monitorv3-ignore.txt   # one extended regex per line: matching error lines are not reported
mkdir -p $STATE_DIR

case "$1" in
  stop)
    if [[ -f $PID_FILE ]] && kill $(cat $PID_FILE) 2>/dev/null; then
      echo "monitorv3 stopped (pid $(cat $PID_FILE))"; rm -f $PID_FILE
    else
      echo "monitorv3 is not running"; rm -f $PID_FILE
    fi
    exit 0 ;;
  status)
    if [[ -f $PID_FILE ]] && kill -0 $(cat $PID_FILE) 2>/dev/null; then
      echo "monitorv3 running (pid $(cat $PID_FILE))"
    else
      echo "monitorv3 is not running"
    fi
    exit 0 ;;
esac

if [[ -f $PID_FILE ]] && kill -0 $(cat $PID_FILE) 2>/dev/null; then
  echo "monitorv3 already running (pid $(cat $PID_FILE)), use: monitorv3.sh stop"; exit 1
fi
echo $$ > $PID_FILE
trap 'rm -f $PID_FILE; echo "monitorv3 stopped"; exit 0' INT TERM

typeset -A offset tomcat_state

ts() { date '+%Y-%m-%d %H:%M:%S' }

alert() {
  local title=$1 msg=$2
  print -r -- "$(ts) ALERT [$title] $msg" | tee -a $ALERT_LOG
  osascript -e "display notification \"${msg//\"/\'}\" with title \"monitorv3: ${title//\"/\'}\" sound name \"Basso\"" 2>/dev/null
}

# Files to watch: Tomcat catalina.out + app logs (the *-json.log files duplicate the plain ones, skip them).
watched_files() {
  for t in $TOMCATS; do print ~/tomcat/${t%%:*}/logs/catalina.out; done
  for f in $APP_LOG_DIR/*.log(N); do [[ $f == *-json.log ]] || print $f; done
}

# Start at the end of every file: only new lines are reported.
for f in $(watched_files); do offset[$f]=$(stat -f %z $f 2>/dev/null || echo 0); done

echo "$(ts) monitorv3 started (pid $$, every ${INTERVAL}s). Stop: monitorv3.sh stop"

while true; do
  # 1. Tomcat process + HTTP port
  for t in $TOMCATS; do
    name=${t%%:*} port=${t##*:}
    if ! pgrep -f "catalina.base=$HOME/tomcat/$name " >/dev/null; then
      state="DOWN (no process)"
    elif ! lsof -nP -iTCP:$port -sTCP:LISTEN >/dev/null 2>&1; then
      state="STARTING/NOT LISTENING on $port"
    else
      state="UP"
    fi
    if [[ ${tomcat_state[$name]} != $state ]]; then
      if [[ $state == UP ]]; then
        echo "$(ts) OK    [$name] UP on port $port"
      elif [[ -n ${tomcat_state[$name]} || $state == DOWN* ]]; then
        alert $name "$state"
      fi
      tomcat_state[$name]=$state
    fi
  done

  # 2. New error lines in the logs
  for f in $(watched_files); do
    size=$(stat -f %z $f 2>/dev/null || echo 0)
    off=${offset[$f]:-0}
    (( size < off )) && off=0            # file truncated/recreated (clearlogs.sh)
    if (( size > off )); then
      if [[ $f == */catalina.out ]]; then pat='SEVERE|Exception'; else pat='\[ERROR |Exception'; fi
      hits=$(tail -c +$((off + 1)) $f | head -c $((size - off)) | grep -E "$pat" | grep -vE '^[[:space:]]+at |^[[:space:]]*\.\.\. [0-9]+ more' | { [[ -s $IGNORE_FILE ]] && grep -vEf $IGNORE_FILE || cat })
      if [[ -n $hits ]]; then
        n=$(print -r -- "$hits" | wc -l | tr -d ' ')
        alert ${f:t} "$n error/exception line(s): $(print -r -- "$hits" | head -1 | cut -c1-160)"
        print -r -- "$hits" | head -10 | cut -c1-300 | sed 's/^/        /' | tee -a $ALERT_LOG
      fi
      offset[$f]=$size
    fi
  done

  sleep $INTERVAL
done
