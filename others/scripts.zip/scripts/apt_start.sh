~/apache-tomcat-8.5/bin/startup.sh
