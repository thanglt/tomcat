aws s3 mb s3://sunnypoint-media-dev --endpoint-url=http://localhost.localstack.cloud:4566 --no-sign-request
aws s3 mb s3://sunnypoint-export-dev --endpoint-url=http://localhost.localstack.cloud:4566 --no-sign-request

~/apache-tomcat-9.0.89/bin/startup.sh
~/apache-tomcat-9.0.89-batch/bin/startup.sh
