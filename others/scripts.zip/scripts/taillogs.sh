ls ~/logs/sunnypoint/* | grep -v json.log$ | xargs tail -f


ls ~/logs/appointment/* | xargs tail -f