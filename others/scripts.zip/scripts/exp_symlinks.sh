ln -s ~/working/profound-experience-japan/src/sunnypoint-web-localcdn/target/webapp-current ~/tomcat-experience/webapps/cdn
ln -s ~/working/profound-experience-japan/src/sunnypoint-liquibase-runner/target/webapp-current ~/tomcat-experience/webapps/liquibase
ln -s ~/working/profound-experience-japan/src/sunnypoint-web-admin/target/webapp-current ~/tomcat-experience/webapps/admin
ln -s ~/working/profound-experience-japan/src/sunnypoint-server/target/webapp-current ~/tomcat-experience/webapps/server
ln -s ~/working/profound-experience-japan/src/sunnypoint-batch/target/webapp-current ~/tomcat-experience/webapps/batch
