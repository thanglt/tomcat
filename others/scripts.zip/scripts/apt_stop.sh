~/apache-tomcat-8.5/bin/shutdown.sh
