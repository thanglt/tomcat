aws s3 mb s3://sunnypoint-media-dev --endpoint-url=http://localhost.localstack.cloud:4566 --no-sign-request
aws s3 mb s3://sunnypoint-export-dev --endpoint-url=http://localhost.localstack.cloud:4566 --no-sign-request

~/tomcat/apache-tomcat-11.0.24/bin/startup.sh
~/tomcat/apache-tomcat-11.0.24-batch/bin/startup.sh
