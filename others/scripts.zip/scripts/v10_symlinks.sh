ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-localcdn/target/webapp-current ~/tomcat/apache-tomcat-10.1.57/webapps/cdn

ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-admin/target/webapp-current ~/tomcat/apache-tomcat-10.1.57/webapps/admin

ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-retailers/target/webapp-current ~/tomcat/apache-tomcat-10.1.57/webapps/retailers

ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-customer/target/webapp-current ~/tomcat/apache-tomcat-10.1.57/webapps/customer

ln -s ~/working/sunnypoint-v3/src/sunnypoint-server/target/webapp-current ~/tomcat/apache-tomcat-10.1.57/webapps/api
ln -s ~/working/sunnypoint-v3/src/sunnypoint-version2-core/target/webapp-current ~/tomcat/apache-tomcat-10.1.57/webapps/v2server

ln -s ~/working/sunnypoint-v3/src/sunnypoint-version2-core/target/webapp-current v2server


ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-takeout/target/webapp-current ~/tomcat/apache-tomcat-10.1.57/webapps/takeout

ln -s ~/working/sunnypoint-v3/src/napolinokama-web/target/webapp-current ~/tomcat/apache-tomcat-10.1.57/webapps/napoli

ln -s ~/working/sunnypoint-v3/src/sunnypoint-liquibase-runner/target/webapp-current ~/tomcat/apache-tomcat-10.1.57-batch/webapps/liquibase
ln -s ~/working/sunnypoint-v3/src/sunnypoint-batch/target/webapp-current ~/tomcat/apache-tomcat-10.1.57-batch/webapps/batch

ln -s ~/working/sunnypoint-v3/src/sunnypoint-coupon-batch/target/webapp-current ~/tomcat/apache-tomcat-10.1.57-batch/webapps/coupon-batch

ln -s ~/working/sunnypoint-v3/src/sunnypoint-message-sender/target/webapp-current ~/tomcat/apache-tomcat-10.1.57-batch/webapps/sender



https://active.amanotesunny.com/customer/views/shopping/default/order-history?accountId=c7a7b54b-4215-4ab4-82fc-54028d7b3bcb&retailerId=91a74429-bce0-4211-96c7-4bc2dd8ff5ec&allShoppingTypes=true