ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-localcdn/target/webapp-current ~/apache-tomcat-9.0.89/webapps/cdn

ln -s ~/working/sunnypoint-v3/src/sunnypoint-liquibase-runner/target/webapp-current ~/apache-tomcat-9.0.89/webapps/liquibase

ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-admin/target/webapp-current ~/apache-tomcat-9.0.89/webapps/admin

ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-retailers/target/webapp-current ~/apache-tomcat-9.0.89/webapps/retailers

ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-customer/target/webapp-current ~/apache-tomcat-9.0.89/webapps/customer

ln -s ~/working/sunnypoint-v3/src/sunnypoint-server/target/webapp-current ~/apache-tomcat-9.0.89/webapps/server

ln -s ~/working/sunnypoint-v3/src/sunnypoint-batch/target/webapp-current ~/apache-tomcat-9.0.89/webapps/batch

ln -s ~/working/sunnypoint-v3/src/sunnypoint-coupon-batch/target/webapp-current ~/apache-tomcat-9.0.89/webapps/coupon-batch

ln -s ~/working/sunnypoint-v3/src/sunnypoint-message-sender/target/webapp-current ~/apache-tomcat-9.0.89/webapps/sender
ln -s ~/working/sunnypoint-v3/src/sunnypoint-web-takeout/target/webapp-current ~/apache-tomcat-9.0.89/webapps/takeout

ln -s ~/working/appointment/appointment-backend/appointment-web-admin/target/webapp-current ~/apache-tomcat-8.5/webapps/admin
ln -s ~/working/appointment/appointment-backend/appointment-salonboard-synchronize/target/webapp-current ~/apache-tomcat-8.5/webapps/salonboard

ln -s ~/working/working/appointment/appointment-backend/appointment-web-admin/target/webapp-current ~/apache-tomcat-9.0.89-appt/webapps/admin
